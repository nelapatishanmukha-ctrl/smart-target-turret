/*
  Smart Turret - Arduino Nano side
  ---------------------------------
  The Processing program (on the laptop) finds a red object with the webcam
  and sends one line of text over USB (COM port) many times per second:

        pan,tilt,laser\n          example:   95,82,1

    pan   = 0..180  angle for the pan  servo (left / right)
    tilt  = 0..180  angle for the tilt servo (up / down)
    laser = 1 -> laser ON, 0 -> laser OFF

  This sketch reads that line, moves the two servos smoothly,
  and switches the laser through a 5V relay module.

  Wiring (Arduino Nano):
    D9  -> Pan  servo signal (orange / yellow wire)
    D10 -> Tilt servo signal (orange / yellow wire)
    D7  -> Relay module IN
    GND -> common GND (servos, relay, laser power supply)
  See docs/circuit_diagram.png

  Serial speed: 115200 baud (must match the Processing sketch)
*/

#include <Servo.h>

// ================== SETTINGS (change these if needed) ==================
const uint8_t PAN_PIN   = 9;      // pan servo signal pin
const uint8_t TILT_PIN  = 10;     // tilt servo signal pin
const uint8_t RELAY_PIN = 7;      // relay module IN pin

// Most blue relay modules switch ON when the IN pin is LOW.
// If your laser is ON when it should be OFF, change true -> false.
const bool RELAY_ACTIVE_LOW = true;

const long BAUD = 115200;

// Safe angle limits, so the servos never hit the frame of the turret.
const int PAN_MIN_ANGLE  = 10;
const int PAN_MAX_ANGLE  = 170;
const int TILT_MIN_ANGLE = 30;
const int TILT_MAX_ANGLE = 150;

// Smooth movement: every STEP_INTERVAL_MS the servo moves at most MAX_STEP degrees.
const unsigned long STEP_INTERVAL_MS = 15;
const int MAX_STEP = 3;

// If no data comes from the laptop for this long, the laser switches OFF (safety).
const unsigned long LINK_TIMEOUT_MS = 1000;
// =======================================================================

Servo panServo;
Servo tiltServo;

int targetPan  = 90;
int targetTilt = 90;
int currentPan  = 90;
int currentTilt = 90;

bool laserWanted = false;     // what the laptop asked for
bool laserState  = false;     // what the relay is doing now

unsigned long lastRxMs   = 0;
unsigned long lastStepMs = 0;

char lineBuf[24];
uint8_t lineLen = 0;

// ---------- relay / laser ----------
void setLaser(bool on) {
  if (on == laserState) return;          // nothing to change
  laserState = on;
  // HIGH when (on and active-high) or (off and active-low)
  bool level = (on == !RELAY_ACTIVE_LOW);
  digitalWrite(RELAY_PIN, level ? HIGH : LOW);
}

// ---------- one received line: "pan,tilt,laser" ----------
void parseLine() {
  int p, t, l;
  if (sscanf(lineBuf, "%d,%d,%d", &p, &t, &l) == 3) {
    targetPan   = constrain(p, PAN_MIN_ANGLE,  PAN_MAX_ANGLE);
    targetTilt  = constrain(t, TILT_MIN_ANGLE, TILT_MAX_ANGLE);
    laserWanted = (l != 0);
    lastRxMs    = millis();
  }
}

void readSerial() {
  while (Serial.available() > 0) {
    char c = (char)Serial.read();
    if (c == '\n') {
      lineBuf[lineLen] = '\0';
      parseLine();
      lineLen = 0;
    } else if (c != '\r') {
      if (lineLen < sizeof(lineBuf) - 1) {
        lineBuf[lineLen++] = c;
      } else {
        lineLen = 0;                     // line too long -> throw it away
      }
    }
  }
}

// move "value" towards "target" by at most MAX_STEP
int stepToward(int value, int target) {
  int diff = target - value;
  if (diff >  MAX_STEP) diff =  MAX_STEP;
  if (diff < -MAX_STEP) diff = -MAX_STEP;
  return value + diff;
}

void setup() {
  // Put the relay in the OFF state BEFORE making the pin an output,
  // so the laser does not blink when the Nano starts.
  digitalWrite(RELAY_PIN, RELAY_ACTIVE_LOW ? HIGH : LOW);
  pinMode(RELAY_PIN, OUTPUT);

  panServo.attach(PAN_PIN);
  tiltServo.attach(TILT_PIN);
  panServo.write(currentPan);
  tiltServo.write(currentTilt);

  Serial.begin(BAUD);
}

void loop() {
  readSerial();

  unsigned long now = millis();

  // move the servos a little bit every few milliseconds
  if (now - lastStepMs >= STEP_INTERVAL_MS) {
    lastStepMs = now;
    currentPan  = stepToward(currentPan,  targetPan);
    currentTilt = stepToward(currentTilt, targetTilt);
    panServo.write(currentPan);
    tiltServo.write(currentTilt);
  }

  // laser only ON while the laptop is talking to us
  bool linkOk = (now - lastRxMs) < LINK_TIMEOUT_MS;
  setLaser(laserWanted && linkOk);
}
