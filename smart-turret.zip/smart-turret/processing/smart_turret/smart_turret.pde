/*
  Smart Turret - Processing side (laptop)
  ----------------------------------------
  1. Opens the laptop webcam.
  2. Finds RED objects in every frame.
  3. Sends  "pan,tilt,laser\n"  to the Arduino Nano on COM4.

  Needs the "Video" library:
     Processing -> Sketch -> Import Library -> Manage Libraries -> search "Video" -> Install
  (The Serial library comes with Processing.)

  KEYS (click the window first)
     Arrow keys : fine-tune aim (trim) so the laser lands on the target
     X          : swap pan direction     (if the turret turns the wrong way left/right)
     Y          : swap tilt direction    (if the turret goes the wrong way up/down)
     A          : arm / disarm laser     (disarmed = laser never turns on)
     M          : show / hide yellow dots of detected red pixels
     + / -      : make red detection stricter / looser
     C          : reset trim
     R          : try to open the COM port again
     H          : show / hide help
     ESC        : quit (laser is switched off)
*/

import processing.video.*;
import processing.serial.*;

// ===================== SETTINGS (change these) =====================
final String PORT_NAME = "COM4";   // Arduino port. Linux: "/dev/ttyUSB0"  Mac: "/dev/cu.usbserial-..."
final int    BAUD      = 115200;   // must match smart_turret.ino

final int CAM_INDEX = 0;           // 0 = first camera. Look at the console for the list.
final int CAM_W = 640;             // keep the same as size(640, 480) in setup()
final int CAM_H = 480;

// How far the servos may turn. Camera left..right  ->  PAN_MIN..PAN_MAX degrees
float PAN_MIN  = 40,  PAN_MAX  = 140;
float TILT_MIN = 60,  TILT_MAX = 120;

// Red detection
final int   STEP       = 4;       // look at every 4th pixel (faster)
final int   MIN_RED    = 100;     // red value must be at least this (0-255)
final int   MIN_PIXELS = 25;      // need this many red pixels to say "target found"
final float SMOOTH     = 0.35;    // 0..1  smaller = smoother but slower
final int   LOST_MS    = 400;     // target lost after this many ms without red
// ==================================================================

Capture cam;
Serial  port;
boolean serialOk = false;
int     serialOpenedAt = 0;
int     lastSendMs = 0;

float ratio = 1.8;                // red must be 1.8x bigger than green and blue
boolean armed = true;
boolean invertPan = false;
boolean invertTilt = false;
boolean showMask = false;
boolean showHelp = true;
float panTrim = 0, tiltTrim = 0;

boolean targetFound = false;
int     lastSeenMs = -100000;
int     redCount = 0;
float   smoothNX = 0.5, smoothNY = 0.5;   // target position, 0..1 across the picture

float panAngle = 90, tiltAngle = 90;
int   laserOn = 0;

void setup() {
  size(640, 480);
  surface.setTitle("Smart Turret");
  frameRate(30);
  textSize(14);

  String[] cams = Capture.list();
  if (cams == null || cams.length == 0) {
    println("No camera found. Plug in / allow the webcam and start again.");
    exit();
    return;
  }
  println("Cameras found:");
  printArray(cams);
  int idx = (CAM_INDEX < cams.length) ? CAM_INDEX : 0;
  cam = new Capture(this, CAM_W, CAM_H, cams[idx]);
  cam.start();

  openSerial();
}

void openSerial() {
  try {
    port = new Serial(this, PORT_NAME, BAUD);
    serialOk = true;
    serialOpenedAt = millis();      // the Nano restarts when the port opens, so we wait 2 s
    println("Opened " + PORT_NAME);
  }
  catch (Exception e) {
    serialOk = false;
    port = null;
    println("Could not open " + PORT_NAME + "  (is the Arduino plugged in? is Serial Monitor closed?)");
    println("Available ports:");
    printArray(Serial.list());
  }
}

void draw() {
  background(0);
  if (cam == null) return;

  if (cam.available()) cam.read();

  if (cam.width > 0) {
    image(cam, 0, 0, width, height);
    detectRed();
  }

  updateAngles();
  sendToArduino();
  drawHud();
}

// ---------- find the red object ----------
void detectRed() {
  cam.loadPixels();
  long sumX = 0, sumY = 0;
  int n = 0;

  for (int y = 0; y < cam.height; y += STEP) {
    int row = y * cam.width;
    for (int x = 0; x < cam.width; x += STEP) {
      int c = cam.pixels[row + x];
      int r = (c >> 16) & 0xFF;
      int g = (c >> 8) & 0xFF;
      int b = c & 0xFF;
      if (r > MIN_RED && r > g * ratio && r > b * ratio) {
        sumX += x;
        sumY += y;
        n++;
        if (showMask) {
          stroke(255, 255, 0);
          point(x * (float)width / cam.width, y * (float)height / cam.height);
        }
      }
    }
  }
  redCount = n;

  if (n >= MIN_PIXELS) {
    float nx = (sumX / (float)n) / cam.width;
    float ny = (sumY / (float)n) / cam.height;
    if (!targetFound) {           // first time we see it: jump straight to it
      smoothNX = nx;
      smoothNY = ny;
    } else {
      smoothNX = lerp(smoothNX, nx, SMOOTH);
      smoothNY = lerp(smoothNY, ny, SMOOTH);
    }
    targetFound = true;
    lastSeenMs = millis();
  } else if (millis() - lastSeenMs > LOST_MS) {
    targetFound = false;
  }
}

// ---------- picture position -> servo angles ----------
void updateAngles() {
  if (targetFound) {
    float nx = invertPan  ? 1 - smoothNX : smoothNX;
    float ny = invertTilt ? 1 - smoothNY : smoothNY;
    panAngle  = constrain(map(nx, 0, 1, PAN_MIN,  PAN_MAX)  + panTrim,  0, 180);
    tiltAngle = constrain(map(ny, 0, 1, TILT_MIN, TILT_MAX) + tiltTrim, 0, 180);
  }
  laserOn = (armed && targetFound) ? 1 : 0;
}

// ---------- send one line to the Arduino ----------
void sendToArduino() {
  if (!serialOk || port == null) return;
  if (millis() - serialOpenedAt < 2000) return;   // wait for the Nano to restart
  if (millis() - lastSendMs < 30) return;         // about 30 lines per second
  lastSendMs = millis();
  try {
    port.write(round(panAngle) + "," + round(tiltAngle) + "," + laserOn + "\n");
  }
  catch (Exception e) {
    serialOk = false;
    println("Lost connection to " + PORT_NAME + ". Press R to try again.");
  }
}

// ---------- screen drawing ----------
void drawHud() {
  strokeWeight(1);
  stroke(0, 255, 0, 70);
  line(width / 2, 0, width / 2, height);
  line(0, height / 2, width, height / 2);

  if (targetFound) {
    float px = smoothNX * width;
    float py = smoothNY * height;
    noFill();
    stroke(0, 255, 0);
    strokeWeight(2);
    ellipse(px, py, 60, 60);
    line(px - 22, py, px + 22, py);
    line(px, py - 22, px, py + 22);
    strokeWeight(1);
  }

  noStroke();
  fill(0, 170);
  rect(0, 0, width, 44);
  fill(255);
  text("Serial: " + (serialOk ? PORT_NAME + " connected" : PORT_NAME + " NOT connected (press R)"), 10, 18);
  fill(targetFound ? color(0, 255, 0) : color(255, 120, 120));
  text(targetFound ? "TARGET LOCKED" : "searching for red...", 10, 36);
  fill(255);
  text("pan " + round(panAngle) + "   tilt " + round(tiltAngle) + "   laser "
       + (laserOn == 1 ? "ON" : "off") + (armed ? "" : "  (DISARMED)"), 230, 18);
  text("red pixels " + redCount + "   strictness " + nf(ratio, 1, 1), 230, 36);

  if (showHelp) {
    fill(0, 170);
    rect(0, height - 62, width, 62);
    fill(255);
    text("Arrows: aim trim    X / Y: swap pan / tilt direction    A: arm laser", 10, height - 42);
    text("M: show red pixels    + / -: stricter / looser    C: reset trim    R: reconnect    H: hide help", 10, height - 22);
  }
}

// ---------- keyboard ----------
void keyPressed() {
  if (key == CODED) {
    if (keyCode == LEFT)  panTrim  -= 1;
    if (keyCode == RIGHT) panTrim  += 1;
    if (keyCode == UP)    tiltTrim += 1;
    if (keyCode == DOWN)  tiltTrim -= 1;
    return;
  }
  switch (Character.toLowerCase(key)) {
    case 'a': armed = !armed; break;
    case 'x': invertPan = !invertPan; break;
    case 'y': invertTilt = !invertTilt; break;
    case 'm': showMask = !showMask; break;
    case 'h': showHelp = !showHelp; break;
    case 'c': panTrim = 0; tiltTrim = 0; break;
    case 'r': if (!serialOk) openSerial(); break;
    case '+':
    case '=': ratio = min(ratio + 0.1, 4.0); break;   // bigger = only very red things
    case '-': ratio = max(ratio - 0.1, 1.2); break;
  }
}

// ---------- on quit: laser OFF ----------
void exit() {
  try {
    if (serialOk && port != null) {
      port.write(round(panAngle) + "," + round(tiltAngle) + ",0\n");
      delay(80);
      port.stop();
    }
  }
  catch (Exception e) {
  }
  super.exit();
}
