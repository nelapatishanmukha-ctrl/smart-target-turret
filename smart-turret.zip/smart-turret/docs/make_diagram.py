#!/usr/bin/env python3
"""Generates the smart-turret circuit diagram (SVG + PNG)."""
import sys

OUT_SVG = sys.argv[1]
W, H = 1720, 1110
OFFY = 125  # diagram group is shifted down to leave room for the title

RED, BLACK, BLUE, ORANGE, YELLOW = "#d62828", "#1b1b1b", "#2f6fe0", "#f08c00", "#c9a200"

parts = []
def add(s): parts.append(s)

def wire(pts, color, w=4):
    d = " ".join(f"{x},{y}" for x, y in pts)
    add(f'<polyline points="{d}" fill="none" stroke="#ffffff" stroke-width="{w+5}" stroke-linejoin="round" stroke-linecap="round"/>')
    add(f'<polyline points="{d}" fill="none" stroke="{color}" stroke-width="{w}" stroke-linejoin="round" stroke-linecap="round"/>')

def dot(x, y, color, r=5.5):
    add(f'<circle cx="{x}" cy="{y}" r="{r}" fill="{color}" stroke="#fff" stroke-width="1.5"/>')

def text(x, y, s, size=14, fill="#222", weight="normal", anchor="start", extra=""):
    add(f'<text x="{x}" y="{y}" font-size="{size}" fill="{fill}" font-weight="{weight}" text-anchor="{anchor}" {extra}>{s}</text>')

# ---------------------------------------------------------------- defs
defs = """
<defs>
  <linearGradient id="pcbBlue" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#1f6fc7"/><stop offset="1" stop-color="#14508f"/></linearGradient>
  <linearGradient id="relayBlue" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3a8be8"/><stop offset="1" stop-color="#1c5fb8"/></linearGradient>
  <linearGradient id="servoBlue" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3c93e6"/><stop offset="1" stop-color="#1d63b3"/></linearGradient>
  <linearGradient id="silver" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f4f4f4"/><stop offset="0.5" stop-color="#b9bcc0"/><stop offset="1" stop-color="#8d9196"/></linearGradient>
  <linearGradient id="brass" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#f3d98b"/><stop offset="0.45" stop-color="#c9a24a"/><stop offset="1" stop-color="#8a6a25"/></linearGradient>
  <linearGradient id="black" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#4a4a4a"/><stop offset="1" stop-color="#1a1a1a"/></linearGradient>
  <linearGradient id="beam" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="#3dff6b" stop-opacity="0.95"/><stop offset="1" stop-color="#3dff6b" stop-opacity="0.05"/></linearGradient>
  <radialGradient id="glow"><stop offset="0" stop-color="#b9ffc9"/><stop offset="0.5" stop-color="#3dff6b" stop-opacity="0.8"/><stop offset="1" stop-color="#3dff6b" stop-opacity="0"/></radialGradient>
  <filter id="shadow" x="-10%" y="-10%" width="125%" height="125%"><feDropShadow dx="2" dy="4" stdDeviation="4" flood-opacity="0.25"/></filter>
</defs>
"""

# ---------------------------------------------------------------- geometry
NX, NY, NW, NH = 250, 170, 150, 400
RIGHT_TIP, LEFT_TIP = NX + NW + 22, NX - 22          # 422, 228
def py(i): return NY + 45 + i * 24
right_pins = ["TX1", "RX0", "RST", "GND", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "D9", "D10", "D11", "D12"]
left_pins  = ["VIN", "GND", "RST", "5V", "A7", "A6", "A5", "A4", "A3", "A2", "A1", "A0", "REF", "3V3", "D13"]
Y = {n: py(i) for i, n in enumerate(right_pins)}      # right side y positions
y_D7, y_D9, y_D10, y_GND = Y["D7"], Y["D9"], Y["D10"], Y["GND"]

X_GND_RAIL, X_5V_RAIL = 700, 740
X_C7, X_C9, X_C10 = 520, 560, 600
CONN_X = 860

PAN_Y, TILT_Y = 320, 470
RELAY_IN_Y, RELAY_GND_Y, RELAY_VCC_Y = 85, 110, 135
TERM_X = 1205
COM_Y, NO_Y, NC_Y = 80, 120, 160
TOP_Y = 30
PSU_GND_Y, PSU_5V_Y = 790, 850
LASER_RED_X, LASER_RED_Y, LASER_BLK_Y = 1360, 120, 136
BLK_RETURN_X = 1300

# ---------------------------------------------------------------- start group
add(f'<g transform="translate(0,{OFFY})">')

# ---------------------------------------------------------------- RAILS
wire([(X_5V_RAIL, TOP_Y), (X_5V_RAIL, PSU_5V_Y)], RED, 6)
wire([(X_GND_RAIL, RELAY_GND_Y), (X_GND_RAIL, PSU_GND_Y)], BLACK, 6)
text(X_5V_RAIL + 12, TOP_Y - 8, "+5V rail", 14, RED, "bold")
text(X_GND_RAIL - 12, 190, "GND rail", 14, BLACK, "bold", "end")

# ---------------------------------------------------------------- POWER WIRES
# supply
wire([(260, PSU_GND_Y), (X_GND_RAIL, PSU_GND_Y)], BLACK)
wire([(260, PSU_5V_Y), (X_5V_RAIL, PSU_5V_Y)], RED)
# relay COM -> +5V rail (over the top)
wire([(TERM_X, COM_Y), (1235, COM_Y), (1235, TOP_Y), (X_5V_RAIL, TOP_Y)], RED)
# relay VCC / GND
wire([(CONN_X, RELAY_VCC_Y), (X_5V_RAIL, RELAY_VCC_Y)], RED)
wire([(CONN_X, RELAY_GND_Y), (X_GND_RAIL, RELAY_GND_Y)], BLACK)
# servos
for cy in (PAN_Y, TILT_Y):
    wire([(CONN_X, cy), (X_5V_RAIL, cy)], RED)
    wire([(CONN_X, cy + 14), (X_GND_RAIL, cy + 14)], BLACK)
# Nano GND -> rail
wire([(RIGHT_TIP, y_GND), (X_GND_RAIL, y_GND)], BLACK)
# laser
wire([(TERM_X, NO_Y), (LASER_RED_X, LASER_RED_Y)], RED)
wire([(LASER_RED_X, LASER_BLK_Y), (BLK_RETURN_X, LASER_BLK_Y), (BLK_RETURN_X, PSU_GND_Y), (X_GND_RAIL, PSU_GND_Y)], BLACK)

# ---------------------------------------------------------------- SIGNAL WIRES
wire([(RIGHT_TIP, y_D7), (X_C7, y_D7), (X_C7, RELAY_IN_Y), (CONN_X, RELAY_IN_Y)], BLUE)
wire([(RIGHT_TIP, y_D9), (X_C9, y_D9), (X_C9, PAN_Y - 14), (CONN_X, PAN_Y - 14)], ORANGE)
wire([(RIGHT_TIP, y_D10), (X_C10, y_D10), (X_C10, TILT_Y - 14), (CONN_X, TILT_Y - 14)], YELLOW)
# fix: servo power wires sit at cy (red) and cy+14 (brown); signal at cy-14
# (the loops above already used cy for red and cy+14 for brown)

# ---------------------------------------------------------------- JUNCTION DOTS
for (x, y, c) in [(X_5V_RAIL, RELAY_VCC_Y, RED), (X_5V_RAIL, PAN_Y, RED), (X_5V_RAIL, TILT_Y, RED), (X_5V_RAIL, PSU_5V_Y, RED),
                  (X_GND_RAIL, RELAY_GND_Y, BLACK), (X_GND_RAIL, y_GND, BLACK), (X_GND_RAIL, PAN_Y + 14, BLACK),
                  (X_GND_RAIL, TILT_Y + 14, BLACK), (X_GND_RAIL, PSU_GND_Y, BLACK)]:
    dot(x, y, c)

# ================================================================ PARTS
# ---------------- Arduino Nano
add(f'<g filter="url(#shadow)">')
add(f'<rect x="{NX}" y="{NY}" width="{NW}" height="{NH}" rx="8" fill="url(#pcbBlue)" stroke="#0d3a6b" stroke-width="2"/>')
add('</g>')
# USB mini connector
add(f'<rect x="{NX+42}" y="{NY-32}" width="66" height="44" rx="5" fill="url(#silver)" stroke="#6b6f74" stroke-width="1.5"/>')
add(f'<rect x="{NX+52}" y="{NY-26}" width="46" height="14" rx="2" fill="#2a2a2a"/>')
# usb cable up to the laptop
add(f'<rect x="{NX+60}" y="{NY-62}" width="30" height="34" rx="4" fill="#3a3a3a"/>')
wire([(NX + 75, NY - 62), (NX + 75, 82)], "#2b2b2b", 5)
# chips
add(f'<rect x="{NX+46}" y="{NY+70}" width="58" height="26" rx="2" fill="url(#black)"/>')
text(NX + 75, NY + 87, "CH340G", 9, "#ddd", "normal", "middle")
add(f'<rect x="{NX+42}" y="{NY+150}" width="66" height="66" rx="3" fill="url(#black)"/>')
add(f'<circle cx="{NX+50}" cy="{NY+158}" r="3" fill="#bbb"/>')
text(NX + 75, NY + 178, "ATmega", 10, "#ddd", "normal", "middle")
text(NX + 75, NY + 192, "328P", 10, "#ddd", "normal", "middle")
for k in range(8):   # tiny chip legs
    a = NX + 46 + k * 8
    add(f'<rect x="{a}" y="{NY+147}" width="3" height="4" fill="#bbb"/><rect x="{a}" y="{NY+215}" width="3" height="4" fill="#bbb"/>')
    b = NY + 154 + k * 8
    add(f'<rect x="{NX+39}" y="{b}" width="4" height="3" fill="#bbb"/><rect x="{NX+107}" y="{b}" width="4" height="3" fill="#bbb"/>')
# crystal, reset button, leds, icsp
add(f'<rect x="{NX+60}" y="{NY+238}" width="30" height="12" rx="6" fill="url(#silver)" stroke="#777"/>')
add(f'<rect x="{NX+63}" y="{NY+118}" width="24" height="24" rx="3" fill="url(#silver)" stroke="#666"/><circle cx="{NX+75}" cy="{NY+130}" r="7" fill="#222"/>')
for (lx, ly, lc, lt) in [(NX+112, NY+262, "#41d36a", "PWR"), (NX+112, NY+278, "#ff9d2e", "L"), (NX+112, NY+294, "#e8e8e8", "TX"), (NX+112, NY+310, "#e8e8e8", "RX")]:
    add(f'<rect x="{lx-26}" y="{ly}" width="9" height="6" fill="{lc}" stroke="#222" stroke-width="0.5"/>')
for r in range(2):
    for c in range(3):
        add(f'<rect x="{NX+58+c*12}" y="{NY+345+r*12}" width="7" height="7" fill="#e0b84a"/>')
text(NX + 20, NY + 345, "ICSP", 8, "#cfe3ff")
# board title (vertical)
# header pads + labels
USED = {"D7": BLUE, "D9": ORANGE, "D10": YELLOW}
for i, n in enumerate(left_pins):
    y = py(i)
    add(f'<line x1="{LEFT_TIP}" y1="{y}" x2="{NX+8}" y2="{y}" stroke="#9a9a9a" stroke-width="3"/>')
    add(f'<circle cx="{NX+9}" cy="{y}" r="5" fill="#e0b84a" stroke="#7a5c10"/>')
    add(f'<circle cx="{LEFT_TIP}" cy="{y}" r="3.5" fill="#e0b84a" stroke="#7a5c10"/>')
    text(NX + 20, y + 4, n, 10.5, "#eaf3ff")
for i, n in enumerate(right_pins):
    y = py(i)
    add(f'<line x1="{NX+NW-8}" y1="{y}" x2="{RIGHT_TIP}" y2="{y}" stroke="#9a9a9a" stroke-width="3"/>')
    add(f'<circle cx="{NX+NW-9}" cy="{y}" r="5" fill="#e0b84a" stroke="#7a5c10"/>')
    add(f'<circle cx="{RIGHT_TIP}" cy="{y}" r="3.5" fill="#e0b84a" stroke="#7a5c10"/>')
    if n in USED or (n == "GND"):
        col = USED.get(n, "#444")
        add(f'<rect x="{NX+NW-44}" y="{y-8}" width="32" height="16" rx="3" fill="{col}"/>')
        text(NX + NW - 28, y + 4, n, 10.5, "#fff", "bold", "middle")
    else:
        text(NX + NW - 20, y + 4, n, 10.5, "#eaf3ff", "normal", "end")
text(NX + 75, NY + NH + 26, "Arduino Nano (ATmega328P)", 15, "#111", "bold", "middle")
text(NX + 75, NY + NH + 44, "powered + programmed by USB", 12.5, "#555", "normal", "middle")

# ---------------- Laptop
lx, ly = 255, -12
add(f'<g filter="url(#shadow)"><rect x="{lx}" y="{ly}" width="140" height="86" rx="6" fill="#2b2f36" stroke="#111" stroke-width="2"/></g>')
add(f'<rect x="{lx+8}" y="{ly+8}" width="124" height="70" fill="#d9e6f2"/>')
add(f'<rect x="{lx+52}" y="{ly+26}" width="30" height="30" rx="3" fill="#e03131"/>')
add(f'<circle cx="{lx+67}" cy="{ly+41}" r="17" fill="none" stroke="#18c23a" stroke-width="2.5"/>')
add(f'<path d="M{lx+53} {ly+41} H{lx+81} M{lx+67} {ly+27} V{ly+55}" stroke="#18c23a" stroke-width="2.5"/>')
add(f'<circle cx="{lx+70}" cy="{ly+4}" r="1.8" fill="#6c7480"/>')
add(f'<path d="M{lx-22} {ly+86} H{lx+162} L{lx+150} {ly+98} H{lx-10} Z" fill="url(#silver)" stroke="#777"/>')
text(430, 5, "Laptop + webcam", 15, "#111", "bold")
text(430, 24, "Processing sketch finds RED,", 13, "#444")
text(430, 41, "talks to the turret on COM4", 13, "#444")

# ---------------- Relay module
RX, RYY, RW, RH = 880, 40, 300, 160
add(f'<g filter="url(#shadow)"><rect x="{RX}" y="{RYY}" width="{RW}" height="{RH}" rx="6" fill="url(#pcbBlue)" stroke="#0d3a6b" stroke-width="2"/></g>')
for (mx, my) in [(RX+9, RYY+9), (RX+RW-9, RYY+9), (RX+9, RYY+RH-9), (RX+RW-9, RYY+RH-9)]:
    add(f'<circle cx="{mx}" cy="{my}" r="4.5" fill="#d8e6f7" stroke="#0d3a6b"/>')
# relay cube
add(f'<rect x="{RX+80}" y="{RYY+22}" width="128" height="102" rx="4" fill="url(#relayBlue)" stroke="#10407f" stroke-width="2"/>')
text(RX + 144, RYY + 55, "SRD-05VDC-SL-C", 11, "#fff", "bold", "middle")
text(RX + 144, RYY + 72, "10A 250VAC  10A 30VDC", 9, "#e6f0ff", "normal", "middle")
text(RX + 144, RYY + 86, "5V coil relay", 9, "#e6f0ff", "normal", "middle")
# opto + transistor + leds
add(f'<rect x="{RX+46}" y="{RYY+104}" width="30" height="20" rx="2" fill="url(#black)"/><text x="{RX+61}" y="{RYY+117}" font-size="8" fill="#ccc" text-anchor="middle">PC817</text>')
add(f'<rect x="{RX+22}" y="{RYY+128}" width="14" height="10" rx="2" fill="url(#black)"/>')
add(f'<rect x="{RX+216}" y="{RYY+100}" width="10" height="7" fill="#ff3b30" stroke="#600" stroke-width="0.5"/><rect x="{RX+216}" y="{RYY+116}" width="10" height="7" fill="#41d36a" stroke="#060" stroke-width="0.5"/>')
# header
for (lab, yy) in [("IN", RELAY_IN_Y), ("GND", RELAY_GND_Y), ("VCC", RELAY_VCC_Y)]:
    add(f'<line x1="{CONN_X}" y1="{yy}" x2="{RX+8}" y2="{yy}" stroke="#9a9a9a" stroke-width="3"/>')
    add(f'<circle cx="{RX+9}" cy="{yy}" r="5" fill="#e0b84a" stroke="#7a5c10"/>')
    add(f'<circle cx="{CONN_X}" cy="{yy}" r="3.5" fill="#e0b84a" stroke="#7a5c10"/>')
    text(RX + 18, yy + 4, lab, 11, "#fff", "bold")
# screw terminal block
add(f'<rect x="{RX+250}" y="{RYY+22}" width="52" height="116" rx="4" fill="#2d6fd0" stroke="#10407f" stroke-width="1.5"/>')
for (lab, yy) in [("COM", COM_Y), ("NO", NO_Y), ("NC", NC_Y)]:
    add(f'<circle cx="{RX+276}" cy="{yy}" r="12" fill="url(#silver)" stroke="#555" stroke-width="1.5"/>')
    add(f'<line x1="{RX+268}" y1="{yy-3}" x2="{RX+284}" y2="{yy+3}" stroke="#444" stroke-width="3"/>')
    add(f'<line x1="{RX+302}" y1="{yy}" x2="{TERM_X}" y2="{yy}" stroke="#9a9a9a" stroke-width="3"/>')
    add(f'<circle cx="{TERM_X}" cy="{yy}" r="3.5" fill="#e0b84a" stroke="#7a5c10"/>')
    text(RX + 244, yy + 4, lab, 11, "#fff", "bold", "end")
text(TERM_X + 10, NC_Y + 4, "NC: not used", 11, "#666")
text(RX + RW / 2, RYY + RH + 22, "5V Relay Module (1-channel)", 15, "#111", "bold", "middle")
text(RX + RW / 2, RYY + RH + 40, "switches the laser ON / OFF", 12.5, "#555", "normal", "middle")

# ---------------- Servos
def servo(cy, label, sub):
    sx, ex = 950, 1090
    # connector + wires
    add(f'<rect x="{CONN_X}" y="{cy-22}" width="26" height="44" rx="3" fill="#161616"/>')
    for k, (c, yy) in enumerate([(ORANGE, cy-14), (RED, cy), ("#6b3e1e", cy+14)]):
        add(f'<line x1="{CONN_X+26}" y1="{yy}" x2="{sx+4}" y2="{cy + (k-1)*6}" stroke="{c}" stroke-width="4" stroke-linecap="round"/>')
    for yy in (cy-14, cy, cy+14):
        add(f'<line x1="{CONN_X}" y1="{yy}" x2="{CONN_X+8}" y2="{yy}" stroke="#e0b84a" stroke-width="4"/>')
        add(f'<circle cx="{CONN_X}" cy="{yy}" r="3.5" fill="#e0b84a" stroke="#7a5c10"/>')
    # ears + body
    add(f'<g filter="url(#shadow)"><rect x="{sx-18}" y="{cy-9}" width="{ex-sx+36}" height="18" rx="3" fill="#2a7bd0" stroke="#10407f"/>')
    add(f'<rect x="{sx}" y="{cy-34}" width="{ex-sx}" height="68" rx="5" fill="url(#servoBlue)" stroke="#10407f" stroke-width="2"/></g>')
    for hx in (sx-9, ex+9):
        add(f'<circle cx="{hx}" cy="{cy}" r="3.8" fill="#dbe9f9" stroke="#10407f"/>')
    text(sx + 40, cy + 5, "SG90", 15, "#fff", "bold", "middle")
    # gear housing + horn
    gx = ex - 28
    add(f'<circle cx="{gx}" cy="{cy}" r="19" fill="#4aa0ee" stroke="#10407f" stroke-width="1.5"/>')
    add(f'<rect x="{gx-34}" y="{cy-7}" width="68" height="14" rx="7" fill="#fafafa" stroke="#999"/>')
    for hh in (-26, -14, 14, 26):
        add(f'<circle cx="{gx+hh}" cy="{cy}" r="1.8" fill="#aaa"/>')
    add(f'<circle cx="{gx}" cy="{cy}" r="6.5" fill="#ececec" stroke="#888"/><circle cx="{gx}" cy="{cy}" r="2.2" fill="#555"/>')
    text(CONN_X, cy - 46, label, 15, "#111", "bold")
    text(CONN_X, cy + 48, sub, 12.5, "#555")
servo(PAN_Y, "PAN servo  (SG90)", "turns the turret left / right")
servo(TILT_Y, "TILT servo  (SG90)", "tilts the laser up / down")

# ---------------- Laser
add(f'<rect x="{LASER_RED_X}" y="{LASER_RED_Y-2}" width="22" height="4" fill="{RED}"/>')
add(f'<rect x="{LASER_RED_X}" y="{LASER_BLK_Y-2}" width="22" height="4" fill="{BLACK}"/>')
add(f'<g filter="url(#shadow)"><rect x="1382" y="{(LASER_RED_Y+LASER_BLK_Y)//2-22}" width="150" height="44" rx="6" fill="url(#brass)" stroke="#6a4f14" stroke-width="1.5"/></g>')
for kx in (1400, 1412, 1424):
    add(f'<line x1="{kx}" y1="{(LASER_RED_Y+LASER_BLK_Y)//2-22}" x2="{kx}" y2="{(LASER_RED_Y+LASER_BLK_Y)//2+22}" stroke="#7a5c14" stroke-width="1.2"/>')
add(f'<rect x="1532" y="{(LASER_RED_Y+LASER_BLK_Y)//2-15}" width="30" height="30" rx="4" fill="url(#silver)" stroke="#555"/>')
cyL = (LASER_RED_Y + LASER_BLK_Y) // 2
add(f'<circle cx="1562" cy="{cyL}" r="10" fill="#0e3a1a" stroke="#333"/><circle cx="1562" cy="{cyL}" r="5" fill="#9dffb4"/>')
add(f'<polygon points="1565,{cyL-3} 1700,{cyL-14} 1700,{cyL+14} 1565,{cyL+3}" fill="url(#beam)"/>')
add(f'<circle cx="1566" cy="{cyL}" r="26" fill="url(#glow)"/>')
text(LASER_RED_X - 6, LASER_RED_Y - 10, "+", 14, RED, "bold", "end")
text(LASER_RED_X - 6, LASER_BLK_Y + 18, "−", 14, "#222", "bold", "end")
text(1382, cyL + 56, "Green Laser Module (5V)", 15, "#111", "bold")
text(1382, cyL + 74, "red wire +, black wire −", 12.5, "#555")

# ---------------- Power supply
add(f'<g filter="url(#shadow)"><rect x="60" y="730" width="200" height="180" rx="10" fill="url(#black)" stroke="#000" stroke-width="2"/></g>')
text(130, 775, "5V  2A", 26, "#fff", "bold", "middle")
text(130, 796, "POWER SUPPLY", 13, "#ccc", "bold", "middle")
text(130, 818, "wall adapter, or power bank", 10.5, "#aaa", "normal", "middle")
text(130, 833, "with a USB breakout board", 10.5, "#aaa", "normal", "middle")
for (lab, yy, colr) in [("−", PSU_GND_Y, "#999"), ("+", PSU_5V_Y, RED)]:
    add(f'<circle cx="236" cy="{yy}" r="12" fill="url(#silver)" stroke="#444" stroke-width="1.5"/>')
    add(f'<line x1="228" y1="{yy-3}" x2="244" y2="{yy+3}" stroke="#444" stroke-width="3"/>')
    add(f'<line x1="248" y1="{yy}" x2="260" y2="{yy}" stroke="#9a9a9a" stroke-width="3"/>')
    text(214, yy + 7, lab, 22, "#fff" if lab == "+" else "#ddd", "bold", "end")
text(160, 935, "External 5V power supply", 15, "#111", "bold", "middle")
text(160, 953, "for servos, relay and laser", 12.5, "#555", "normal", "middle")

# ---------------- Wiring table
TX, TY = 880, 560
add(f'<rect x="{TX}" y="{TY}" width="395" height="200" rx="8" fill="#f6f8fb" stroke="#b7c2d0"/>')
text(TX + 16, TY + 26, "WIRING TABLE", 15, "#111", "bold")
rows = [
    (BLUE,   "Nano D7  →  Relay IN"),
    (ORANGE, "Nano D9  →  PAN servo signal"),
    (YELLOW, "Nano D10 →  TILT servo signal"),
    (BLACK,  "Nano GND →  GND rail (common GND)"),
    (RED,    "+5V supply → servo red, relay VCC, relay COM"),
    (RED,    "Relay NO  →  Laser +    Laser − → GND"),
]
for k, (c, s) in enumerate(rows):
    yy = TY + 52 + k * 22
    add(f'<rect x="{TX+16}" y="{yy-10}" width="22" height="7" rx="3" fill="{c}"/>')
    text(TX + 48, yy, s, 13.5, "#222")
text(TX + 16, TY + 190, "All GND wires must be joined together!", 13.5, RED, "bold")

add('</g>')

# ---------------------------------------------------------------- title (outside group)
header = f'''
<text x="40" y="52" font-size="36" font-weight="bold" fill="#111">Smart Turret – Circuit Diagram</text>
<text x="40" y="80" font-size="16" fill="#555">Arduino Nano  +  2 servos (pan / tilt)  +  5V relay module  +  laser   •   Processing finds red objects with the laptop webcam</text>
'''

svg = f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" font-family="Arial, Helvetica, sans-serif">' \
      f'{defs}<rect width="{W}" height="{H}" fill="#ffffff"/>{header}' + "\n".join(parts) + '</svg>'
open(OUT_SVG, "w").write(svg)
print("wrote", OUT_SVG)
